import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: ContactsPage(),
    );
  }
}

class ContactsPage extends StatefulWidget {
  @override
  State<ContactsPage> createState() => _ContactsPageState();
}

class _ContactsPageState extends State<ContactsPage> {
  final contacts = [
    Contact(
      name: "John Doe",
      email: 'john_doeoe@gmail.com',
      favorite: false,
    ),
    Contact(
      name: "Racheal G. Thompson",
      email: 'bradley28@gmail.com',
      favorite: false,
    ),
    Contact(
      name: "Susan E. Yen",
      email: 'vincent30@hotmail.com',
      favorite: false,
    ),
    Contact(
      name: "John A. Lange",
      email: 'verona_parker@zohomail.com',
      favorite: false,
    ),
    Contact(
      name: "John C. Milbourn",
      email: 'sylvester_dunne@protonmail.com',
      favorite: false,
    )
  ];

  int contador = 0;
  void incrementa() {
    setState(() {
      contador++;
    });
  }

  void decrementa() {
    setState(() {
      contador--;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Contatos Favoritos $contador'),
      ),
      body: ListView.builder(
        itemCount: contacts.length,
        itemBuilder: (context, index) {
          return ListTile(
            leading: CircleAvatar(
              backgroundImage: NetworkImage('https://i.pravatar.cc/150?img=?'),
            ),
            title: Text(contacts[index].name),
            subtitle: Text(contacts[index].email),
            trailing: IconButton(
              icon: Icon(
                contacts[index].favorite
                    ? Icons.favorite
                    : Icons.favorite_border,
                color: contacts[index].favorite ? Colors.red : null,
              ),
              onPressed: () {
                setState(() {
                  contacts[index].favorite = !contacts[index].favorite;
                  if (contacts[index].favorite) {
                    incrementa();
                  } else {
                    decrementa();
                  }
                });
              },
            ),
          );
        },
      ),
    );
  }
}

class Contact {
  String name;
  String email;
  bool favorite = false;

  Contact({
    required this.name,
    required this.email,
    required this.favorite,
  });
}
